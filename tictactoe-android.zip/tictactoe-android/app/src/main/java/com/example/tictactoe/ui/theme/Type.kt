package com.example.tictactoe.ui.theme

import androidx.compose.material3.Typography

// Default Material 3 typography
val Typography = Typography()
