package com.example.tictactoe.ui.theme

import androidx.compose.ui.graphics.Color

val Pink = Color(0xFFFF4DA6)
val Blue = Color(0xFF3B82F6)
val Black = Color(0xFF000000)
val SurfaceDark = Color(0xFF121212)
